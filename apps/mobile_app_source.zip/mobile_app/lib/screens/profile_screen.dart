// lib/screens/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/supabase_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final user = FirebaseAuth.instance.currentUser;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController homeGymController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  String selectedPlan = 'base_tier';

  bool isLoading = true;
  final SupabaseService supabaseService = SupabaseService();

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    final profile = await supabaseService.fetchFullUser(user?.email ?? '');
    if (profile != null) {
      emailController.text = profile['email'];
      homeGymController.text = profile['home_gym'] ?? '';
      selectedPlan = profile['plan'] ?? 'base_tier';
    }
    setState(() => isLoading = false);
  }

  Future<void> saveProfile() async {
    final currentEmail = user?.email ?? '';
    final newEmail = emailController.text.trim();
    final newHomeGym = homeGymController.text.trim();
    final newPassword = newPasswordController.text.trim();

    try {
      // Update Firebase email
      if (newEmail != currentEmail) {
        await user?.updateEmail(newEmail);
      }

      // Update Firebase password
      if (newPassword.isNotEmpty) {
        await user?.updatePassword(newPassword);
      }

      // Update Supabase profile
      await supabaseService.updateUserProfile(
        newEmail,
        selectedPlan,
        newHomeGym,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully')),
      );
    } catch (e) {
      print('Error updating profile: $e');
      //await logEvent('updating profile', 'Error updating profile', context: {'error': e.toString()});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    TextFormField(
                      controller: emailController,
                      decoration: const InputDecoration(labelText: 'Email'),
                    ),
                    TextFormField(
                      controller: newPasswordController,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'New Password (optional)'),
                    ),
                    TextFormField(
                      controller: homeGymController,
                      decoration: const InputDecoration(labelText: 'Home Gym'),
                    ),
                    DropdownButtonFormField<String>(
                      value: selectedPlan,
                      decoration: const InputDecoration(labelText: 'Plan'),
                      items: const [
                        DropdownMenuItem(value: 'base_tier', child: Text('Base Tier')),
                        DropdownMenuItem(value: 'mid_tier', child: Text('Mid Tier')),
                        DropdownMenuItem(value: 'premium_tier', child: Text('Premium Tier')),
                      ],
                      onChanged: (value) => setState(() => selectedPlan = value!),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: saveProfile,
                      child: const Text('Save Changes'),
                    )
                  ],
                ),
              ),
            ),
    );
  }
}
