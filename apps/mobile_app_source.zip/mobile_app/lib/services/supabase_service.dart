import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;
import 'package:intl/intl.dart';
import 'package:supabase/supabase.dart';
import '../supabase_config.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';

Future<Map<String, String>> getDeviceMetadata() async {
  final deviceInfo = DeviceInfoPlugin();

  if (Platform.isAndroid) {
    final androidInfo = await deviceInfo.androidInfo;
    return {
      'device_model': androidInfo.model ?? 'unknown',
      'os_version': 'Android ${androidInfo.version.release}',
    };
  } else if (Platform.isIOS) {
    final iosInfo = await deviceInfo.iosInfo;
    return {
      'device_model': iosInfo.utsname.machine ?? 'unknown',
      'os_version': 'iOS ${iosInfo.systemVersion}',
    };
  }

  return {
    'device_model': 'unknown',
    'os_version': 'unknown',
  };
}

Future<Map<String, String>> getAuthHeaders() async {
  final user = fb_auth.FirebaseAuth.instance.currentUser;
  if (user != null) {
    final idToken = await user.getIdToken();
    return {
      'Authorization': 'Bearer $idToken',
      'apikey': supabaseKey, // still required by Supabase
      'Content-Type': 'application/json',
    };
  } else {
    throw Exception('User is not authenticated');
  }
}

/// Represents clip metadata from the Supabase `clips` table.
class ClipMetadata {
  final String filepath;
  final String createdAt;
  final String signedURL;
  final int duration;

  ClipMetadata({
    required this.filepath,
    required this.createdAt,
    required this.signedURL,
    required this.duration,
  });

  factory ClipMetadata.fromJson(Map<String, dynamic> json) {
    return ClipMetadata(
      filepath: json['filepath'],
      createdAt: json['created_at'],
      signedURL: json['signed_url'],
      duration: json['duration'],
    );
  }
}

class SupabaseService {
  /// Fetch all clips (fallback or admin use)
  Future<List<ClipMetadata>> fetchClips() async { 
    final headers = await getAuthHeaders();
    final response = await http.get(
      Uri.parse('$supabaseUrl/rest/v1/clips?select=*'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);
      return jsonData.map((e) => ClipMetadata.fromJson(e)).toList();
    } else {
      throw Exception('Failed to fetch clips: ${response.statusCode}');
    }
  }

final SupabaseClient _client = SupabaseClient(
    supabaseUrl,
    supabaseKey,
  );

 // Optional: expose client for other services like AppLogger
SupabaseClient get client => _client;

/// Returns the current Firebase user's email, or null if not signed in.
String? getCurrentUserEmail() {
  final user = fb_auth.FirebaseAuth.instance.currentUser;
  return user?.email;
}


Future<String?> fetchUserRole(String email) async {
  final response = await _client
      .from('user_list')
      .select('role')
      .eq('email', email)
      .maybeSingle();

  return response?['role'];
}

Future<void> insertLogEvent({
  required String category,
  required String message,
  String? severity,
  String? emailOverride,
  Map<String, dynamic>? extraFields
}) async {
  final email = emailOverride ?? fb_auth.FirebaseAuth.instance.currentUser?.email;
  final timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());

  final base = {
    'email': email ?? 'anonymous',
    'category': category,
    'message': message,
    'timestamp': timestamp,
    'severity': severity ?? 'info',
  };

  final data = {
    ...base,
    ...?extraFields, // ✅ Merge any extras like device_model, etc.
  };

  print('📝 Logging payload: ${json.encode(data)}');

  try {
  await _client.from('log_events').insert(data);
} catch (e) {
  print('⚠️ Failed to insert log event: $e');
}
}


  /// Insert new user to user_list
  Future<void> insertUser(
      String email, String qrId, String plan, String homeGym) async {
    final headers = await getAuthHeaders();
    final response = await http.post(
      Uri.parse('$supabaseUrl/rest/v1/user_list'),
      headers: headers,
      body: json.encode({
        'email': email,
        'qr_id': qrId,
        'plan': plan,
        'home_gym': homeGym,
        'downloads': 0,
      }),
    );

    if (response.statusCode >= 400) {
      throw Exception('Failed to insert user: ${response.body}');
    }
  }

  /// Fetch user row by email
  Future<Map<String, dynamic>?> fetchUser(String email) async {
    final headers = await getAuthHeaders();
    final res = await http.get(
      Uri.parse('$supabaseUrl/rest/v1/user_list?email=ilike.$email&select=email,qr_id,plan,home_gym,downloads'),

      headers: headers,
    );

    final data = json.decode(res.body);
    return (data as List).isNotEmpty ? data[0] : null;
  }

    /// Fetch full user row by email
  Future<Map<String, dynamic>?> fetchFullUser(String email) async {
    final headers = await getAuthHeaders();
    final res = await http.get(
      Uri.parse('$supabaseUrl/rest/v1/user_list?email=eq.$email&select=*'),
      headers: headers,
    );
    final data = json.decode(res.body);
    return (data as List).isNotEmpty ? data[0] : null;
  }

  /// Update user profile (plan/home_gym)
Future<void> updateUserProfile(String email, String plan, String homeGym) async {
  final headers = await getAuthHeaders();

  final Uri patchUrl = Uri.parse('$supabaseUrl/rest/v1/user_list?email=eq.$email');

  print('[Supabase] PATCH URL: $patchUrl');
  print('[Supabase] PATCH Headers: $headers');
  print('[Supabase] PATCH Body: ${json.encode({'plan': plan, 'home_gym': homeGym})}');

  final res = await http.patch(
    patchUrl,
    headers: {
      //headers: headers,
      ...headers,
      'Prefer': 'return=representation', // Returns affected row
    },
    body: json.encode({'plan': plan, 'home_gym': homeGym}),
  );

  print('[Supabase] PATCH Response: ${res.statusCode}');
  print('[Supabase] PATCH Body: ${res.body}');

  if (res.statusCode >= 400) {
    throw Exception('Failed to update user profile: ${res.body}');
  }

  if (res.statusCode == 204 || res.body.trim() == '[]') {
    print('[Supabase] ⚠️ Update returned no matching rows. Check email or RLS policy.');
  } else {
    print('[Supabase] ✅ Profile updated: ${res.body}');
  }
}

    /// Update FCM token for a user by email
  Future<void> updateFcmToken(String email, String token) async {
    final headers = await getAuthHeaders();
    final res = await http.patch(
      Uri.parse('$supabaseUrl/rest/v1/user_list?email=eq.$email'),
      headers: {
        ...headers,
        'Prefer': 'return=representation',
      },
      body: jsonEncode({'fcm_token': token}),
    );

    print('[Supabase] FCM token update response: ${res.statusCode} - ${res.body}');

    if (res.statusCode >= 400) {
      throw Exception('Failed to update FCM token: ${res.body}');
    }
  }

  /// Fetch clips for a specific QR ID
  Future<List<ClipMetadata>> fetchClipsByQrId(String qrId) async {
    final headers = await getAuthHeaders();
    final res = await http.get(
      Uri.parse('$supabaseUrl/rest/v1/clips?qr_ids=like.*$qrId*'),
      headers: headers,
    );

    if (res.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(res.body);
      return jsonData.map((e) => ClipMetadata.fromJson(e)).toList();
    } else {
      throw Exception('Failed to fetch clips by QR ID: ${res.statusCode}');
    }
  }

  /// Insert user profile
  Future<void> insertUserProfile(
      String email, String plan, String homeGym, String qrId) async {
    final headers = await getAuthHeaders();
    final response = await http.post(
      Uri.parse('$supabaseUrl/rest/v1/user_list'),
      headers: {
        ...headers,
        'Prefer': 'return=minimal'
      },
      body: jsonEncode({
        'email': email,
        'plan': plan,
        'home_gym': homeGym,
        'qr_id': qrId,
        'downloads': 0,
      }),
    );

    if (response.statusCode != 201 && response.statusCode != 200) {
      print('Failed to insert user profile: ${response.body}');
      throw Exception('User insert failed');
    }
  }

  /// Fetch current user's QR ID
  Future<String?> fetchCurrentUserQrId(String email) async {
    final cleanEmail = email.trim().toLowerCase();
    final url = '$supabaseUrl/rest/v1/user_list?email=eq.$cleanEmail&select=qr_id';
    print("Fetching from Supabase with URL: $url");
    print("Supabase headers: apikey=$supabaseKey");
    final headers = await getAuthHeaders();
    final response = await http.get(
      Uri.parse(url),
      headers: headers,
    );

    print("Supabase response status: ${response.statusCode}");
    print("Supabase response body: ${response.body}");

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      if (data.isNotEmpty && data.first['qr_id'] != null) {
        print("Fetched QR ID: ${data.first['qr_id']}");
        return data.first['qr_id'].toString();
      } else {
        print("No matching record or qr_id is null for $cleanEmail");
      }
    } else {
      print("Failed to fetch qr_id: ${response.body}");
    }

    return null;
  }
}
