import 'package:firebase_auth/firebase_auth.dart';
import 'supabase_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final SupabaseService _supabaseService = SupabaseService();

  /// Stream to monitor user login state
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Sign up a new user with email + password, and insert into Supabase user_list
  Future<User?> signUp({
    required String email,
    required String password,
    required String plan,
    required String homeGym,
    required String qrId,
  }) async {
    final userCredential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    final user = userCredential.user;
    if (user != null) {
      await _supabaseService.insertUserProfile(
        email,
        qrId,
        plan,
        homeGym,
      );
    }

    return user;
  }

  /// Login existing user with email + password
  Future<User?> signIn({
    required String email,
    required String password,
  }) async {
    final userCredential = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    return userCredential.user;
  }

  /// Sign out the current user
  Future<void> signOut() async {
    await _auth.signOut();
  }

  /// Fetch the current user's QR ID from Supabase
  Future<String?> getQrIdForCurrentUser() async {
    final user = _auth.currentUser;
    if (user?.email != null) {
      return await _supabaseService.fetchCurrentUserQrId(user!.email!);
    }
    return null;
  }
}