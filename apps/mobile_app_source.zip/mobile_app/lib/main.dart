import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:video_player/video_player.dart';
import 'dart:math';
import 'services/supabase_service.dart';
import 'services/auth_service.dart';
import 'widgets/drawer_widgets.dart';
import 'screens/profile_screen.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'utils/logging_context.dart';
import 'utils/logger.dart';
import 'utils/secure_storage.dart';

final supabaseService = SupabaseService();
final authService = AuthService();
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();
final AppLogger logger = AppLogger(supabaseService);
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'default_channel', // must match AndroidManifest
  'Default Notifications',
  description: 'Used for basic notifications',
  importance: Importance.defaultImportance,
);

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  await logger.logEvent('notifications', 'Background message received', context: {
    'title': message.notification?.title,
    'body': message.notification?.body,
  });
}


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await LoggingContext.initialize();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
  );

  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  final messaging = FirebaseMessaging.instance;

// Request permissions on iOS/Android 13+
await messaging.requestPermission();

// Create channel for Android
await flutterLocalNotificationsPlugin
    .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
    ?.createNotificationChannel(channel);

// Init local notifications
await flutterLocalNotificationsPlugin.initialize(
  const InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    iOS: DarwinInitializationSettings(),
  ),
);

// Handle FCM token registration
final token = await messaging.getToken();
final user = fb_auth.FirebaseAuth.instance.currentUser;
final email = user?.email;

if (token != null && email != null) {
  await supabaseService.updateFcmToken(email, token);
  await logger.logEvent('notifications', 'FCM token registered', context: {'token': token});
}

// Foreground notification listener
FirebaseMessaging.onMessage.listen((RemoteMessage message) {
  final notification = message.notification;
  final android = message.notification?.android;
  if (notification != null && android != null) {
    flutterLocalNotificationsPlugin.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          channel.id,
          channel.name,
          channelDescription: channel.description,
          icon: '@mipmap/ic_launcher',
        ),
      ),
    );
  }
});


  runApp(const RollItBackApp());
}

class RollItBackApp extends StatelessWidget {
  const RollItBackApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Roll It Back',
      theme: ThemeData.dark(),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  late final Stream<fb_auth.User?> _authStream;
  fb_auth.User? _currentUser;

  @override
  void initState() {
    super.initState();
    _authStream = fb_auth.FirebaseAuth.instance.authStateChanges();
    Future.microtask(() async {
      await _attemptBiometricLogin();
    });

    Future.microtask(() async => await _postInitAsync());
  }

  Future<void> _postInitAsync() async {
    await setupFirebaseMessaging();

    _authStream.listen((user) async {
      if (user == null) {
        await logger.logEvent('auth', 'User logged out');
      } else if (user.email != null) {
        await logger.logEvent('auth', 'User logged in', context: {
          'email': user.email,
        });
      }
    });
  }



  @override
  Widget build(BuildContext context) {
    return StreamBuilder<fb_auth.User?>(
      stream: _authStream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        } else if (snapshot.hasData) {
          return const ClipListScreen();
        } else {
          return const AuthScreen();
        }
      },
    );
  }

  Future<void> setupFirebaseMessaging() async {
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  // Request permission (for iOS)
  await messaging.requestPermission();

  // Get and print FCM token (for testing)
  String? token = await messaging.getToken();
  if (fb_auth.FirebaseAuth.instance.currentUser != null) {
    if (fb_auth.FirebaseAuth.instance.currentUser?.email != null) {
      await logger.logEvent('notifications', 'FCM token registered', context: {'token': token});
    }
  }


  // Listen to foreground messages
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    RemoteNotification? notification = message.notification;
    if (notification != null) {
      flutterLocalNotificationsPlugin.show(
        notification.hashCode,
        notification.title,
        notification.body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'default_channel',
            'Default',
            importance: Importance.max,
            priority: Priority.high,
          ),
        ),
      );
    }
  });
}

Future<bool> authenticateWithBiometrics() async {
  final localAuth = LocalAuthentication();
  final canCheck = await localAuth.canCheckBiometrics;
  final isAvailable = await localAuth.isDeviceSupported();

  if (!canCheck || !isAvailable) return false;

  try {
    final didAuthenticate = await localAuth.authenticate(
      localizedReason: 'Please authenticate to continue',
      options: const AuthenticationOptions(
        biometricOnly: true,
        stickyAuth: true,
      ),
    );
    return didAuthenticate;
  } catch (e) {
    await logger.logEvent('auth', 'Biometric auth error', context: {
        'error': e.toString()
      });
    return false;
  }
}

Future<void> _attemptBiometricLogin() async {
  final prefs = await SharedPreferences.getInstance();
  final useFingerprint = prefs.getBool('useFingerprint') ?? false;
  final staySignedIn = prefs.getBool('staySignedIn') ?? false;
  final existingUser = fb_auth.FirebaseAuth.instance.currentUser;

  if (staySignedIn && existingUser?.email != null) {
    await logger.logEvent('auth', 'Auto login via staySignedIn');
    return; // Let StreamBuilder handle routing
  }

  if (!useFingerprint) return;

  final stored = await SecureStorage.readCredentials();
  final storedEmail = stored['email'];
  final storedPassword = stored['password'];

  if (storedEmail == null || storedPassword == null) {
    await logger.logEvent('auth', 'No stored credentials for biometric login');
    return;
  }

  const maxAttempts = 5;

  for (int attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      final success = await authenticateWithBiometrics();

      if (success) {
        // Attempt Firebase sign-in
        try {
          await fb_auth.FirebaseAuth.instance.signInWithEmailAndPassword(
            email: storedEmail,
            password: storedPassword,
          );

          await logger.logEvent('auth', 'Biometric login success');
          return; // Let StreamBuilder navigate to ClipListScreen
        } catch (e) {
          await logger.logEvent('auth', 'Firebase login failed after biometrics', context: {
            'error': e.toString(),
          });
          break; // Don’t retry on Firebase error
        }
      } else {
        final remaining = maxAttempts - attempt;

        await logger.logEvent('auth', 'Biometric login failed', context: {
          'attempt': attempt,
          'remaining': remaining,
        });

        if (mounted && remaining > 0) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Fingerprint failed. You have $remaining attempt(s) left.')),
          );
        }

        // If user cancelled scan on first attempt → force logout
        if (attempt == 1) {
          await AppDrawer.globalSignOut(context);
          return;
        }
      }
    } catch (e) {
      // System or plugin error (less common)
      await logger.logEvent('auth', 'Biometric scan error', context: {
        'attempt': attempt,
        'error': e.toString(),
      });
      await AppDrawer.globalSignOut(context);
      return;
    }
  }

  // All 5 attempts failed
  await logger.logEvent('auth', 'Biometric login failed 5 times — logging out');
  await AppDrawer.globalSignOut(context);
}
}


class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final gymController = TextEditingController();
  String selectedPlan = 'base_tier';
  bool isSignup = false;
  bool _passwordVisible = false;


  Future<void> authenticate() async {
  final email = emailController.text.trim();
  final password = passwordController.text.trim();

  // Save credentials to SecureStorage *only if* fingerprint is enabled
  final prefs = await SharedPreferences.getInstance();
  final useFingerprint = prefs.getBool('useFingerprint') ?? false;
  if (useFingerprint) {
    await SecureStorage.saveCredentials(email, password);
  }

  if (isSignup) {
    try {
      // 1. Create Firebase user
      await fb_auth.FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // 2. Generate QR ID
      final qrId = (Random().nextInt(900000000) + 100000000).toString();

      // 3. Insert profile into Supabase
      try {
        await supabaseService.insertUser(
          email,
          qrId,
          selectedPlan,
          gymController.text.trim(),
        );
      } catch (e, stack) {
        await logger.logEvent('signup', 'Supabase insertUser error', context: {'error': e.toString()});

        await logger.logEvent('category', 'Some error', context: {'error': e.toString(),'stack': stack.toString(),});
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Signup error: Failed to save profile. $e")),
        );
      }
    } catch (e, stack) {
      await logger.logEvent('signup', 'Firebase signup error', context: {'error': e.toString()});

      await logger.logEvent('category', 'Some error', context: {'error': e.toString(),'stack': stack.toString(),});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Signup error: $e")),
      );
    }
  } else {
    try {
      await fb_auth.FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e, stack) {
      await logger.logEvent('login', 'Firebase login error', context: {'error': e.toString()});
      await logger.logEvent('category', 'Some error', context: {'error': e.toString(),'stack': stack.toString(),});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Login error: $e")),
      );
    }
  }

  final fcmToken = await FirebaseMessaging.instance.getToken();

  if (fcmToken != null) {
    await supabaseService.updateFcmToken(email, fcmToken);
  }

  final user = fb_auth.FirebaseAuth.instance.currentUser;
  if (user != null) {
    await logger.logEvent('auth', 'User metadata after login', context: {
      'uid': user.uid,
      'email': user.email,
      'emailVerified': user.emailVerified,
      'providers': user.providerData.map((e) => e.providerId).join(', '),
    });
  }

  if (mounted) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const ClipListScreen()),
    );
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Roll It Back Auth')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: const InputDecoration(labelText: 'Email')),
            TextField(
              controller: passwordController,
              obscureText: !_passwordVisible,
              decoration: InputDecoration(
                labelText: 'Password',
                suffixIcon: IconButton(
                  icon: Icon(_passwordVisible ? Icons.visibility : Icons.visibility_off),
                  onPressed: () {
                    setState(() {
                      _passwordVisible = !_passwordVisible;
                    });
                  },
                ),
              ),
            ),
            if (isSignup) ...[
              TextField(controller: gymController, decoration: const InputDecoration(labelText: 'Home Gym')),
              DropdownButtonFormField<String>(
                value: selectedPlan,
                items: const [
                  DropdownMenuItem(value: 'base_tier', child: Text('Base Tier')),
                  DropdownMenuItem(value: 'mid_tier', child: Text('Mid Tier')),
                  DropdownMenuItem(value: 'premium_tier', child: Text('Premium Tier')),
                ],
                onChanged: (value) => setState(() => selectedPlan = value!),
                decoration: const InputDecoration(labelText: 'Plan'),
              ),
            ],
            ElevatedButton(onPressed: authenticate, child: Text(isSignup ? 'Sign Up' : 'Log In')),
            TextButton(
              onPressed: () => setState(() => isSignup = !isSignup),
              child: Text(isSignup ? 'Already have an account? Log in' : 'No account? Sign up'),
            ),
          ],
        ),
      ),
    );
  }
}

class ClipListScreen extends StatefulWidget {
  const ClipListScreen({super.key});
  @override
  State<ClipListScreen> createState() => _ClipListScreenState();
}

class _ClipListScreenState extends State<ClipListScreen> {
  List<dynamic> clips = [];
  String? userQrId;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserClips();
  }

  Future<void> fetchUserClips() async {
    try {
    final email = fb_auth.FirebaseAuth.instance.currentUser?.email;
    final qrId = await supabaseService.fetchCurrentUserQrId(email ?? '');

    if (email == null || email.trim().isEmpty) {
      await logger.logEvent('clip_list', 'No email found for current user');
      setState(() => isLoading = false);
      return;
    }

    if (qrId != null) {
      final filteredClips = await supabaseService.fetchClipsByQrId(qrId);
      setState(() {
        userQrId = qrId;
        clips = filteredClips;
        isLoading = false;
      });
    } else {
      await logger.logEvent('clip_list', 'QR ID was null: check Supabase user_list table');

    }
  } catch (e, stack) {
    await logger.logEvent('clip_list', 'Error fetching user clips', context: {'error': e.toString()});
    await logger.logEvent('category', 'Some error', context: {'error': e.toString(),'stack': stack.toString(),});
    setState(() => isLoading = false);
  }
  }

  void playClip(String url) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => ClipPlayerScreen(url: url)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Clips'),
      ),
      drawer: const AppDrawer(),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: clips.length,
                    itemBuilder: (context, index) {
                      final clip = clips[index];
                      return ListTile(
                        title: Text(clip.filepath),
                        subtitle: Text('Duration: ${clip.duration}'),
                        trailing: const Icon(Icons.play_arrow),
                        onTap: () => playClip(clip.signedURL),
                      );
                    },
                  ),
                ),
                //if (userQrId != null)
                  //Container(
                  //  padding: const EdgeInsets.all(8),
                  //  color: Colors.black54,
                  //  child: Text('Your QR ID: $userQrId', style: const TextStyle(color: Colors.white)),
                  //)
              ],
            ),
    );
  }
}

class ClipPlayerScreen extends StatefulWidget {
  final String url;
  const ClipPlayerScreen({super.key, required this.url});
  @override
  State<ClipPlayerScreen> createState() => _ClipPlayerScreenState();
}

class _ClipPlayerScreenState extends State<ClipPlayerScreen> {
  late VideoPlayerController controller;

  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.network(widget.url)
      ..initialize().then((_) => setState(() {}))
      ..play();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Playing Clip')),
      body: Center(
        child: controller.value.isInitialized
            ? AspectRatio(aspectRatio: controller.value.aspectRatio, child: VideoPlayer(controller))
            : const CircularProgressIndicator(),
      ),
    );
  }
}
