"""Role: evaluation utilities package."""
