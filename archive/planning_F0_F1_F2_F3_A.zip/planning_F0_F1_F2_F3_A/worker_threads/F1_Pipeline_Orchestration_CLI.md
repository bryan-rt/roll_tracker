# F1 — Pipeline Orchestration & CLI


## Update: F0 + F3 are complete (locked constraints)

### F3 (Stage 0 ingest) — locked input contract
- Ingest writes clips to: `data/raw/nest/<camera_id>/YYYY-MM-DD/HH/<camera_id>-YYYYMMDD-HHMMSS.mp4`
- Processing reads only from `data/raw/**`
- Outputs written only to `outputs/<clip_id>/...` (see F0 layout)
- Ingest service lives under `services/nest_recorder/` (Docker-based)

### F0 (contracts) — authoritative source of truth
All stage I/O **must** follow the contracts in:
- `src/bjj_pipeline/contracts/f0_models.py`
- `src/bjj_pipeline/contracts/f0_parquet.py`
- `src/bjj_pipeline/contracts/f0_paths.py`
- `src/bjj_pipeline/contracts/f0_manifest.py`
- `src/bjj_pipeline/contracts/f0_validate.py`

Do **not** invent schemas locally. If you need a change, propose it as “Manager Decision Needed” with a schema version bump.

### Locked artifact families (by stage)
Stage A — Detection & Tracklets (must write):
- `stage_A/detections.parquet`
- `stage_A/tracklet_frames.parquet`
- `stage_A/tracklet_summaries.parquet`
- `stage_A/audit.jsonl`

Stage B — Masks & Geometry:
- `stage_B/contact_points.parquet`
- `stage_B/masks/*.npz` (canonical mask storage; referenced by relative path)
- `stage_B/audit.jsonl`

Stage C — Identity Anchoring (AprilTags):
- `stage_C/tag_observations.jsonl`
- `stage_C/identity_hints.jsonl` (must_link / cannot_link keyed to tracklet_id; anchor_key like `tag:<tag_id>`)
- `stage_C/audit.jsonl`

Stage D — Global Stitching (MCF):
- `stage_D/person_tracks.parquet`
- `stage_D/identity_assignments.jsonl` (final identities keyed to person_id)
- `stage_D/audit.jsonl`

Stage E — Match Sessions:
- `stage_E/match_sessions.jsonl`
- `stage_E/audit.jsonl`

Stage F — Export & Persistence:
- `stage_F/export_manifest.jsonl`
- exported `.mp4` clips
- `stage_F/audit.jsonl`

### Locked output layout + manifest backbone
Each run is anchored by:
- `outputs/<clip_id>/clip_manifest.json`

Stages must:
1) Read inputs from the manifest (or well-defined raw input path for Stage A)
2) Write artifacts to their stage folder
3) Register artifact paths in the manifest
4) Validate outputs via `f0_validate.py` before claiming completion

---

## Standard context: full pipeline (POC, offline, BJJ practice)

### What we are building
An **offline** (batch) video processing pipeline for BJJ practice footage. Input is a saved ~2.5 minute clip. Output is:
- **Stitched per-athlete trajectories** (stable person identities across time)
- **“Who vs who” match sessions** (start/end via hysteresis on ground-plane distance)
- **Exported match clips** (cropped, optionally privacy-redacted)
- **Database rows + audit logs** (opt-in compliance and debugging)

### Non‑negotiables (manager-locked constraints)
- **Min-Cost Flow (MCF) stitching is mandatory** (no Hungarian tracklet linking as the final association method).
- **Offline-first design**: we may use an “online tracker” (BoT-SORT) only as a *tracklet generator*.
- **AprilTags are hard identity anchors**: must-link / cannot-link constraints must be enforced in stitching.
- **Homography is used to compute ground-plane (x,y) in meters** from an on-mat contact point.
- **Modularity + contract-first**: every stage reads/writes versioned artifacts defined in `F0`.
- **Deterministic + debuggable**: every stage must produce debug/audit artifacts explaining key decisions.

### Pipeline stages (high level)
1) **Stage A — Detect + Tracklets (local association)**
   - Tooling target: detector (YOLO or similar) + tracker (BoT-SORT via BoxMOT).
   - Output: frame-level detections + short, high-precision **tracklets** (intentionally allowed to break).

2) **Stage B — Masks + contact point + homography (offline refinement)**
   - Tooling target: SAM/SAM2 offline refinement (or fallback masks) + OpenCV.
   - Output: mask references + stable “ground contact point” per frame + projected ground-plane coordinates.

3) **Stage C — Identity anchoring (AprilTag scanning + registry)**
   - Tooling target: AprilTag detection applied inside mask ROI + voting registry.
   - Output: tag observations (frame-level) + stable identity assignments + conflicts.

4) **Stage D — Global stitching (Min-Cost Flow)**
   - Tooling target: MCF solver (start with OR-Tools or NetworkX; optimize later).
   - Inputs: tracklets + (x,y) + (optional) ReID similarity + AprilTag constraints.
   - Output: stitched person tracks across entire clip.

5) **Stage E — Match session detection (hysteresis)**
   - Tooling target: deterministic state machine on pairwise distances.
   - Output: match sessions (who vs who, start/end, confidence, evidence).

6) **Stage F — Export + privacy + database**
   - Tooling target: ffmpeg (clip/crop), optional mask-based redaction, SQLite/Postgres persistence.
   - Output: mp4 clips + metadata rows + audit trails.

### Canonical tool choices (POC defaults)
These are defaults; workers may propose alternatives but must align with constraints.
- **Tracking**: BoxMOT **BoT-SORT** (as tracklet generator)
- **Masks**: YOLO-seg online where possible; **SAM/SAM2 offline** where higher fidelity needed
- **AprilTags**: Python apriltag detector (library choice can be decided in C1)
- **ReID (optional early, likely later)**: OSNet / torchreid or FastReID; ideally on masked crops
- **Stitching**: **Min-Cost Flow** (OR-Tools min-cost flow or NetworkX as baseline)
- **Video I/O**: OpenCV for reading frames when needed; ffmpeg for export
- **Data**: JSONL for event logs; Parquet for high-volume tables (decide in F0/F2)

### Contracts & artifacts (must be defined centrally in F0)
Workers should assume the following artifact families will exist, with exact schemas defined in F0:
- `detections` (per-frame detections)
- `tracklets` (tracklet spans + summaries)
- `masks` (mask references, RLE/paths) and `contact_points` (u,v and x,y)
- `tag_observations` (frame-level tag detections) and `identity_assignments`
- `person_tracks` (stitched per-person timeline)
- `match_sessions`
- `export_manifest` / DB rows / audit logs

### Definition of “done” for a worker thread
A worker thread is “done” only when it returns to the Manager:
- **Design Spec** (assumptions, algorithm, edge cases, failure modes)
- **Interface Contract** (inputs/outputs + invariants, including artifact schema deltas if any)
- **Copilot Prompt Pack** (file-by-file prompts) and/or **Acceptance Criteria** (tests + checks)


---


## Module-specific context (F1 — orchestration/CLI)
We want a repeatable, deterministic way to run stages on a clip and persist artifacts.

### Must include
- A stage runner convention: each stage has `run.py` with a `main()` and a callable `run(config, inputs)->outputs`
- CLI commands:
  - `roll-tracker run --clip <path> --camera cam01 --out outputs/...`
  - `roll-tracker stage detect-track ...`
  - `roll-tracker stage stitch ...`
- How to resume from artifacts (skip completed stages)
- Standard logging + error handling (fail fast, write audit event)

### Invariants
- No stage reads another stage’s internals; only reads artifacts via F0 contracts
- Config is always explicit (no hidden globals)


---


## Worker responsibilities in this thread

Produce deliverables that are directly usable by the Manager and by GitHub Copilot. Keep scope strictly within this module.

### Required outputs back to Manager
- **Design Spec**: approach, assumptions, edge cases, failure modes, performance notes (POC-level)
- **Interface Contract**: exact input/output artifacts and invariants (propose schema changes to F0 explicitly)
- **Copilot Prompt Pack**: prompts per file (or per function), with acceptance tests
- **Acceptance Criteria**: checklist + unit tests (and synthetic fixtures where possible)

### Guardrails (anti-drift)
- Do not invent new stages.
- Do not change global constraints (MCF mandatory, AprilTags as anchors, offline-first).
- If you need a cross-module change, propose it explicitly as a “Manager Decision Needed”.


---


## Kickoff (what to do first in this worker thread)
Please begin by producing:
1) A **proposed plan** for this module (bullets are fine), including key decisions and tradeoffs.
2) A list of **questions / assumptions** you need confirmed.
3) A draft **Interface Contract** for this module (even if some fields are TBD pending F0).

End your first response by asking me to review/approve the plan before you go deeper.

Also include a bullet explicitly confirming alignment with the locked F0/F3 contracts (artifacts, paths, manifest).

---

## F1 — Finalized Orchestration Behavior (Post-Implementation)

This section documents **final, implemented behavior** of the F1 orchestration layer.  
It is authoritative for how the pipeline actually runs today.

### Clip identity (clip_id) — **LOCKED**
- `clip_id` is defined as the **filename stem** (no extension).
- Example:
  ```
  data/raw/nest/cam03/2026-01-03/12/cam03-20260103-124000.mp4
  → clip_id = "cam03-20260103-124000"
  ```
- Orchestrator **fails fast** if:
  - The ingest path does not match `data/raw/nest/<camera_id>/YYYY-MM-DD/HH/...`
  - The directory camera_id does not match `--camera`
  - The filename stem does not begin with `<camera_id>-`

This rule is deterministic, human-readable, and matches the ingest contract.

### Config loading & merge semantics — **LOCKED**
Config is always explicit and merged in this order:

1) `configs/default.yaml` (if present)  
2) `configs/cameras/<camera_id>.yaml` (if present)  
3) `--config` overlay (JSON or YAML, optional)

Merge rule:
- **Deep merge**
- Later sources override earlier ones
- Non-dict values fully replace earlier values

### Run anchor & outputs
Each orchestration run is anchored at:

```
outputs/<clip_id>/
  ├── clip_manifest.json
  ├── orchestration_audit.jsonl
  ├── stage_A/
  ├── stage_B/
  ├── ...
```

There is **no run_id layer**. The clip is the unit of work.

### Orchestration audit (run-level)
In addition to per-stage `stage_*/audit.jsonl`, F1 writes:

```
outputs/<clip_id>/orchestration_audit.jsonl
```

This file records:
- `run_started`, `run_finished`, `run_failed`
- `stage_started`, `stage_succeeded`, `stage_skipped`, `stage_failed`
- Skip reasons (validated outputs, config hash match)
- Error summaries on failure

The orchestration audit **is registered in `clip_manifest.json`** as a non-stage artifact.

### Resume / skip semantics (authoritative)
A stage is considered **complete and skippable** iff **all** are true:

1) All required output files for the stage exist (per F0 locked layout)  
2) Outputs pass `f0_validate.py` for that stage  
3) The stage’s config hash matches the last successful run recorded in `orchestration_audit.jsonl`  
4) The user did not request `--force` (or `--force-stage`)

If any check fails, the stage re-runs.

### Stage runner contract — **HARD REQUIREMENT**
Every stage **must** expose the following in `run.py`:

```python
def run(config: dict, inputs: dict) -> dict:
    ...
```

Notes:
- Orchestrator **calls this directly**
- Stages must write their locked artifacts before returning
- A missing `run()` is considered a fatal implementation error

### CLI surface (final)
Implemented and tested commands:

```bash
roll-tracker run --clip <path> --camera cam03 --out outputs/
roll-tracker stage stitch --clip <path> --camera cam03
roll-tracker status --clip <path> --camera cam03
roll-tracker validate --clip <path> --camera cam03
```

Flags:
- `--from-stage`, `--to-stage`
- `--force`
- `--force-stage <A|B|C|D|E|F>`
- `--out` overrides outputs root (default: `outputs/`)

### F1 Status

**F1 — Pipeline Orchestration & CLI is COMPLETE.**

---

## F1.1 — Added Requirement: Homography Preflight (Camera Calibration)

The Manager added an explicit requirement that **before Stage A runs**, orchestration must ensure a valid homography exists for the camera. fileciteturn3file0L70-L77

### Homography file location (DECIDED)
Homography is stored per camera at:

```
configs/cameras/<camera_id>/homography.json
```

Example:
```
configs/cameras/cam03/homography.json
```

### Preflight behavior (authoritative)
When a pipeline run includes Stage A (i.e., stage window contains `A`), orchestration must:

1) Resolve `camera_id` from CLI / ingest path validation (already required).
2) Check for presence of `configs/cameras/<camera_id>/homography.json`.
3) If missing:
   - **Interactive mode enabled**: invoke the homography calibrator, then re-check for the file.
   - **Interactive mode disabled**: fail fast with a clear error indicating how to create it.

All downstream stages assume homography exists and is valid. fileciteturn3file0L70-L77

### CLI surface additions
Add an explicit flag to orchestration commands:

- `roll-tracker run ... --interactive`
- `roll-tracker stage ... --interactive`

Default is **non-interactive** (fail-fast if missing).

### Audit requirements
Orchestration must write run-level audit events into:

```
outputs/<clip_id>/orchestration_audit.jsonl
```

Recommended event names:
- `homography_preflight_started`
- `homography_preflight_succeeded`
- `homography_preflight_missing`
- `homography_preflight_failed`

(Per-stage `stage_*/audit.jsonl` remains unchanged.)

### Minimal homography validation (until B3 locks schema)
Until B3 defines a strict schema, preflight should validate only:
- file exists
- JSON parses to an object/dict
- if the JSON contains an `H` field, it should be a 3×3 numeric matrix

If B3 later defines a stricter schema, update this check accordingly.

### Manager Decision Needed (ONLY if undefined elsewhere)
- The **calibrator entrypoint** to launch in interactive mode (module/CLI name), unless already defined in B3.

## Checkpoint discipline

**All workers must keep the pipeline runnable end-to-end at every checkpoint.**  
This is a non-negotiable POC constraint to prevent drift and ensure incremental validation.

Minimum requirements for *any* stage/worker deliverable:

- Provide a `run()` implementation that is callable by orchestration: `def run(config: dict, inputs: dict) -> dict`.
- Ensure artifacts written match **F0** contracts and pass `roll-tracker validate`.
- Add at least one *realistic* smoke test (pytest) that:
  - runs the stage on a small fixture (or mocked inputs), and
  - asserts the expected artifacts exist and validate.
- Ensure the manager can run:
  - `roll-tracker run --clip <path> --camera <camera_id> --to-stage <your_stage>`
  - and receive deterministic outputs under `outputs/<clip_id>/...`.

If performance becomes an issue, prefer reducing resolution / selecting fewer candidates over skipping frames at POC time.

## Post-F2 integration notes

- Resolved config (including optional `configs/cameras/<camera_id>/homography.json`) is produced by F2 loader and emitted to `orchestration_audit.jsonl` as `event_type=config_resolved`.
- Homography **preflight** remains an orchestration responsibility: check presence/shape before Stage A when required; do not rely on downstream stages to handle missing homography.
